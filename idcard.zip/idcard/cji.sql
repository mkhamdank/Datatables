-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 07, 2018 at 12:00 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cji`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id_login` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `noHp` bigint(20) NOT NULL,
  `level` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id_login`, `username`, `password`, `nama`, `alamat`, `noHp`, `level`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Admin', 'Jalan Rejoso', 852, 1),
(2, 'ndan', '15e8d4e206d050a4adc9ddbd203bdaf5', 'Khamdan', 'Jalan', 865, 2),
(3, 'fandi', '9bb773615bccfc87168aa059884ca038', 'Fandi', 'Jalan', 865, 3);

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `id_person` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `no_ktp` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `fk_perusahaan` int(11) NOT NULL,
  `reg_num` varchar(20) NOT NULL,
  `foto_ktp` text NOT NULL,
  `foto_diri` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`id_person`, `nama`, `no_ktp`, `address`, `fk_perusahaan`, `reg_num`, `foto_ktp`, `foto_diri`) VALUES
(25, 'Udin', '1234667', 'Jalan Anggur', 9, '07082018.000001', 'Hydrangeas.jpg', 'g1.jpg'),
(26, 'Nita', '67567', 'Jalan Nanas', 9, '07082018.000002', 'Chrysanthemum.jpg', 'g3.jpg'),
(27, 'Adi', '67858', 'Jalan Manggis', 9, '07082018.000003', 'Lighthouse.jpg', 'g2.jpg'),
(28, 'Bagas', '675678', 'Jalan Ganggang', 9, '07082018.000004', 'Tulips.jpg', 'g1.jpg'),
(29, 'Rukma', '78687', 'Jalan Gurami', 9, '07082018.000005', 'Penguins.jpg', 'g2.jpg'),
(30, 'Bagas', '678', 'Jalan', 10, '07082018.000006', 'Koala.jpg', 'g1.jpg'),
(31, 'Rukma', '6876587', 'Jalan', 10, '07082018.000007', 'Koala.jpg', 'g2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `perusahaan`
--

CREATE TABLE `perusahaan` (
  `id_perusahaan` int(11) NOT NULL,
  `nama_perusahaan` varchar(100) NOT NULL,
  `alias` varchar(20) NOT NULL,
  `safety_permit_number` varchar(20) NOT NULL,
  `mulai_bekerja` date NOT NULL,
  `finish_work` date NOT NULL,
  `reg_date` date NOT NULL,
  `foto_safety_permit` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `perusahaan`
--

INSERT INTO `perusahaan` (`id_perusahaan`, `nama_perusahaan`, `alias`, `safety_permit_number`, `mulai_bekerja`, `finish_work`, `reg_date`, `foto_safety_permit`) VALUES
(9, 'PT Maju Jaya', 'PT MJ', '123456', '2018-08-01', '2018-08-31', '2018-08-07', 'Desert1.jpg'),
(10, 'PT Pertamina', 'PT P', '67858', '2018-08-31', '2018-08-30', '2018-08-07', 'g31.jpg'),
(11, 'oioi', 'uiiu', '67868', '2018-08-17', '2018-08-23', '2018-08-07', 'Chrysanthemum1.jpg'),
(12, 'dsada', 'dasd', '15', '2018-12-12', '1984-12-01', '2018-08-07', '17098235_1613435342003449_3480311414754491776_n.jpg'),
(13, 'dsada', 'dasd', '15', '2018-12-12', '1984-12-01', '2018-08-07', '17098235_1613435342003449_3480311414754491776_n1.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id_login`);

--
-- Indexes for table `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`id_person`),
  ADD KEY `fk_perusahaan` (`fk_perusahaan`);

--
-- Indexes for table `perusahaan`
--
ALTER TABLE `perusahaan`
  ADD PRIMARY KEY (`id_perusahaan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id_login` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `person`
--
ALTER TABLE `person`
  MODIFY `id_person` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `perusahaan`
--
ALTER TABLE `perusahaan`
  MODIFY `id_perusahaan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `person`
--
ALTER TABLE `person`
  ADD CONSTRAINT `person_ibfk_1` FOREIGN KEY (`fk_perusahaan`) REFERENCES `perusahaan` (`id_perusahaan`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
