<!DOCTYPE html>
<html lang="">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Data Contractor PT CJI</title>

		<!-- Bootstrap CSS -->
		<!-- <link rel="stylesheet" href="<?php echo base_url('') ?>assets/css/bootstrap.min.css"> -->
		<link rel="stylesheet" href="<?php echo base_url('') ?>assets/datatables.min.css">
		<link rel="stylesheet" href="<?php echo base_url().'assets/jquery-ui.css'?>">
		<link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso16.css" /> 
		<style>
		.form-control:focus{border-color: #5cb85c;  box-shadow: none; -webkit-box-shadow: none;} 
		.form-control:invalid{box-shadow: none; -webkit-box-shadow: none;border-color: red;}
		</style>
		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body>
		
		<div class="container">
			<nav class="navbar navbar-default" role="navigation">
				<div class="container-fluid">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="#">Data Contractor PT CJI</a>
					</div>
			
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse navbar-ex1-collapse">
						<ul class="nav navbar-nav">
							<li class="active"><a class="nav-link" href="<?php echo site_url('Home/create') ?>">Tambah Perusahaan <span class="sr-only">(current)</span></a></li>
							<li><a class="nav-link" href="<?php echo site_url('Home/report_perusahaan') ?>">Daftar Perusahaan</a></li>
							<li><a class="nav-link" href="<?php echo site_url('Home/report_person') ?>">Daftar Personil</a></li>
							<li><a class="nav-link" href="<?php echo site_url('Login/logout') ?>">Logout</a></li>
						</ul>
						
					</div><!-- /.navbar-collapse -->
				</div>
			</nav>

						<legend><center>Tambah Perusahaan</center></legend>
						<?php echo form_open_multipart('Home/create'); ?>
						<?php echo validation_errors() ?>
					
						<div class="form-group">
							<div>
							<label for="nama_perusahaan">Nama Perusahaan</label>
							<input type="text" class="form-control has-error" id="nama_perusahaan" placeholder="Nama Perusahaan" name="nama_perusahaan" required="">

							<label for="alias">Alias</label>
							<input type="text" class="form-control" id="alias" placeholder="Alias" name="alias"  required="">

							<label for="safety_permit_number">Safety Permit Number</label>
							<input type="text" class="form-control" id="" placeholder="Safety Permit Number" name="safety_permit_number" required="">
							<input type="file" class="form-control" id="" name="userfile">

							<label for="mulai_bekerja">Tanggal Mulai Bekerja</label>
							<input type="date" class="form-control" id="" name="mulai_bekerja" required="">

							<label for="finish_work">Tanggal Terakhir Bekerja</label>
							<input type="date" class="form-control" id="" name="finish_work" required="">

							<label for="jumlah_personil">Jumlah Personil</label>
							<input type="number" class="form-control" id="" name="jumlah_personil" placeholder="Jumlah Personil" required="" >
							</div>

						</div>
					
						
					
						<button type="submit" class="btn btn-primary" onclick="validate()">Submit</button>
					</form>
				</div>



		<!-- jQuery -->
		<script src="<?php echo base_url().'assets/jquery-3.3.1.js'?>" type="text/javascript"></script>
		<!-- Bootstrap JavaScript -->
		<script src="<?php echo base_url('') ?>assets/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url('') ?>assets/datatables.min.js"></script>
		<script src="<?php echo base_url().'assets/jquery-ui.js'?>" type="text/javascript"></script>
		<script type="text/javascript">
        $(document).ready(function(){
	            $( "#nama_perusahaan" ).autocomplete({
	              source: "<?php echo site_url('Home/get_autocomplete/?');?>"
	            });
	        });
	    </script>
		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
		<script type="text/javascript">
		$(document).ready(function() {
    		$('#example').DataTable();
		} );	
		</script>
		<!-- <script>
			function validate(){
			    //form validation
			    var name=document.getElementById('nama_perusahaan');
			     if (name.value == null || name.value==""){
			       name.style.backgroundColor="##ff3f3f";
			       name.focus();
			       return false;    // add this line
			     }
			     var alias=document.getElementById('alias');
			     if (alias.value == null || alias.value==""){
			       alias.style.backgroundColor="##ff3f3f";
			       alias.focus();
			       return false;    // add this line
			     }
			}   // This was missing
		</script> -->
	</body>
</html>