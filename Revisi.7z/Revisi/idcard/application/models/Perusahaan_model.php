<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Perusahaan_model extends CI_Model {

	public function create()
	{
		$object = array('nama_perusahaan' => $this->input->post('nama_perusahaan'),
		'alias' => $this->input->post('alias'),
		'safety_permit_number' => $this->input->post('safety_permit_number'),
		'mulai_bekerja' => $this->input->post('mulai_bekerja'),
		'finish_work' => $this->input->post('finish_work'),
		'reg_date' => date("Y/m/d"),
		'foto_safety_permit' => $this->upload->data('file_name') );
		$this->db->insert('perusahaan', $object);
	}

	public function getPerusahaan()
	{
		$data = $this->db->get('perusahaan');
		return $data->result();
	}


	public function getPerusahaanById($id_perusahaan)
	{
		$this->db->where('id_perusahaan', $id_perusahaan);
		return $this->db->get('perusahaan')->result();
	}

	public function getPerusahaanByNama($nama_perusahaan)
	{
		$this->db->where('nama_perusahaan', $nama_perusahaan);
		return $this->db->get('perusahaan')->result();
	}


}

/* End of file Perusahaan_model.php */
/* Location: ./application/models/Perusahaan_model.php */