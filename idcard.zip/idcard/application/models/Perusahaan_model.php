<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Perusahaan_model extends CI_Model {

	public function create()
	{
		$object = array('nama_perusahaan' => $this->input->post('nama_perusahaan'),
		'alias' => $this->input->post('alias'),
		'safety_permit_number' => $this->input->post('safety_permit_number'),
		'mulai_bekerja' => $this->input->post('mulai_bekerja'),
		'finish_work' => $this->input->post('finish_work'),
		'reg_date' => date("Y/m/d"),
		'foto_safety_permit' => $this->upload->data('file_name') );
		$this->db->insert('perusahaan', $object);
	}

	function search_perusahaan($title){
        $this->db->like('nama_perusahaan', $title , 'both');
        $this->db->order_by('nama_perusahaan', 'ASC');
        $this->db->limit(10);
        return $this->db->get('perusahaan')->result();
    }

	public function getPerusahaanById($id_perusahaan)
	{
		$this->db->where('id_perusahaan', $id_perusahaan);
		return $this->db->get('perusahaan')->result();
	}

	public function getPerusahaan()
	{
		$data = $this->db->get('perusahaan');
		return $data->result();
	}

	public function getPerusahaanByNama($nama_perusahaan)
	{
		$this->db->where('nama_perusahaan', $nama_perusahaan);
		return $this->db->get('perusahaan')->result();
	}

	public function updateById($id_perusahaan)
	{
		$data = array('nama_perusahaan' =>$this->input->post('nama_perusahaan'),
					'alias' =>$this->input->post('alias'),
					'safety_permit_number' =>$this->input->post('safety_permit_number'),
					'mulai_bekerja' =>$this->input->post('mulai_bekerja'),
					'finish_work' =>$this->input->post('finish_work'),
					'reg_date' =>$this->input->post('reg_date'),
					'foto_safety_permit'=>$this->upload->data('file_name'),);
		$this->db->where('id_perusahaan', $id_perusahaan);
		$this->db->update('perusahaan', $data);
	}

	public function delete($id_perusahaan)
	{
		$this->db->where('id_perusahaan', $id_perusahaan);
		$this->db->delete('perusahaan');
	}

	public function check_safetyNumber($safety_permit_number)
	{
		$this->db->select('safety_permit_number');
		$this->db->where('safety_permit_number', $safety_permit_number);
		$query = $this->db->get('perusahaan');
		$row = $query->row();
		if ($query->num_rows >0) {
			return $row->safety_permit_number;
		}
		else {
			return"";
		}
	}
}

/* End of file Perusahaan_model.php */
/* Location: ./application/models/Perusahaan_model.php */