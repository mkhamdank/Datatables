<!DOCTYPE html>
<html lang="">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Data Contractor PT CJI</title>

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="<?php echo base_url('') ?>assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="<?php echo base_url('') ?>assets/datatables.min.css">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body>
		<div class="container">
			<nav class="navbar navbar-default" role="navigation">
				<div class="container-fluid">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="#">Data Contractor PT CJI</a>
					</div>
			
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse navbar-ex1-collapse">
						<ul class="nav navbar-nav">
							<?php if ($level == 3): ?>
								<li><a class="nav-link" href="<?php echo site_url('Home/create') ?>">Tambah Perusahaan <span class="sr-only">(current)</span></a></li>
								<li><a class="nav-link" href="<?php echo site_url('Home/report_perusahaan') ?>">Daftar Perusahaan</a></li>
								<li class="active"><a class="nav-link" href="<?php echo site_url('Home/report_person') ?>">Daftar Personil</a></li>
							<?php endif ?>
							<?php if ($level == 1): ?>
								<li><a class="nav-link" href="<?php echo site_url('Perusahaan') ?>">Daftar Perusahaan <span class="sr-only">(current)</span></a></li>
								<li class="active"><a class="nav-link" href="<?php echo site_url('Person') ?>">Daftar Personil</a></li>
								<li><a class="nav-link" href="<?php echo site_url('User') ?>">Daftar User</a></li>
							<?php endif ?>
							<?php if ($level == 2): ?>
								<li><a class="nav-link" href="<?php echo site_url('Perusahaan') ?>">Daftar Perusahaan <span class="sr-only">(current)</span></a></li>
								<li class="active"><a class="nav-link" href="<?php echo site_url('Person') ?>">Daftar Personil</a></li>
							<?php endif ?>
							<li><a class="nav-link" href="<?php echo site_url('Login/logout') ?>">Logout</a></li>
						</ul>
						
					</div><!-- /.navbar-collapse -->
				</div>
			</nav>

			
			<div class="col-12">
				<legend><center>Data Personil</center></legend>
				<table class="table" id="example">
					<thead>
						<th>Nama PT</th>
						<th>Nama Lengkap</th>
						<th>Nomor KTP</th>
						<th>Alamat</th>
						<th>Nomor Registrasi</th>
						<th>Foto KTP</th>
						<th>Foto Diri</th>
						<th>Action</th>
					</thead>
					<tbody>
						<?php foreach($person as $key){ ?>
									<tr>
										<td><?php echo $key->nama_perusahaan ?></td>
										<td><?php echo $key->nama ?></td>
										<td><?php echo $key->no_ktp ?></td>
										<td><?php echo $key->address ?></td>
										<td><?php echo $key->reg_num ?></td>
										<td><a class="MagicZoom" href="<?=base_url("assets/uploads")."/".$key->foto_ktp?>" rel="zoom-id:zoom;opacity-reverse:true;"><img style="width: 100px; height: auto;" src="<?=base_url("assets/uploads")."/".$key->foto_ktp?>" alt="" /> </a></td>
										<td><a class="MagicZoom" href="<?=base_url("assets/uploads")."/".$key->foto_diri?>" rel="zoom-id:zoom;opacity-reverse:true;"><img style="width: 100px; height: auto;" src="<?=base_url("assets/uploads")."/".$key->foto_diri?>" alt="" /> </a></td>
										
										<td>
											<a href="<?=site_url()?>/Person/update/<?php echo $key->id_person.'/'.$key->foto_ktp.'/'.$key->foto_diri ?>"><button class="btn btn-primary" data-title="Edit" data-toggle="modal" data-target="#edit"><span class="glypchon glypchon-pencil">Edit</span></button></a>
										    <?php if ($level == 1): ?>
										    	<a href="<?=site_url()?>/Person/delete/<?php echo $key->id_person.'/'.$key->foto_ktp.'/'.$key->foto_diri ?>"><button class="btn btn-danger" data-title="Delete" data-toggle="modal" data-target="#edit"><span class="glypchon glypchon-pencil">Delete</span></button></a>
										    <?php endif ?>
										</td>
									</tr>
								<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
		<!-- jQuery -->
		<script src="//code.jquery.com/jquery.js"></script>
		<!-- Bootstrap JavaScript -->
		<script src="<?php echo base_url('') ?>assets/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url('') ?>assets/datatables.min.js"></script>
		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
		<script type="text/javascript">
		$(document).ready(function() {
    		$('#example').DataTable();
		} );	
		</script>
	</body>
</html>