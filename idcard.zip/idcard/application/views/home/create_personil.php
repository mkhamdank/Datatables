<!DOCTYPE html>
<html lang="">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Data Contractor PT CJI</title>

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="<?php echo base_url('') ?>assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="<?php echo base_url('') ?>assets/datatables.min.css">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body>
		<div class="container">
					<nav class="navbar navbar-default" role="navigation">
				<div class="container-fluid">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="#">Data Contractor PT CJI</a>
					</div>
			
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse navbar-ex1-collapse">
						<ul class="nav navbar-nav">
							<li class="active"><a class="nav-link" href="<?php echo site_url('Home/create') ?>">Tambah Perusahaan <span class="sr-only">(current)</span></a></li>
							<li><a class="nav-link" href="<?php echo site_url('Home/report_perusahaan') ?>">Daftar Perusahaan</a></li>
							<li><a class="nav-link" href="<?php echo site_url('Home/report_person') ?>">Daftar Personil</a></li>
							<li><a class="nav-link" href="<?php echo site_url('Login/logout') ?>">Logout</a></li>
						</ul>
						
					</div><!-- /.navbar-collapse -->
				</div>
			</nav>
						<?php echo form_open_multipart('Home/create_personil/'.$this->uri->segment(3).'/'.$this->uri->segment(4)); ?>
							<legend><center> Tambah Personil Contractor</center></legend>
							<?php echo validation_errors() ?>
						
							<div class="form-group">
								<?php for ($i=0; $i < $jumlah_personil; $i++) { ?>
									<p><b>Personil <?php echo $i+1 ?></b></p>
									<label for="">Nama</label>
									<input type="text" class="form-control" id="" placeholder="Nama" name="nama[]">
									<input type="file" class="form-control" name="filefoto<?php echo $i;?>">

									<label for="">Nomor KTP</label>
									<input type="text" class="form-control" id="" placeholder="Nomor KTP" name="no_ktp[]">
									<input type="file" class="form-control" name="filefotoktp<?php echo $i;?>">

									<label for="">Alamat</label>
									<input type="text" class="form-control" id="" placeholder="Alamat" name="address[]">


									<br>
								<?php } ?>
								<input type="hidden" value="hidden" name="hidden">
							</div>
						
							
						
							<button type="submit" class="btn btn-primary">Submit</button>
						</form>
					</div>



		<!-- jQuery -->
		<script src="//code.jquery.com/jquery.js"></script>
		<!-- Bootstrap JavaScript -->
		<script src="<?php echo base_url('') ?>assets/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url('') ?>assets/datatables.min.js"></script>
		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
		<script type="text/javascript">
		$(document).ready(function() {
    		$('#example').DataTable();
		} );	
		</script>
	</body>
</html>