<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url','form','file');
		$this->load->library('form_validation');
		$this->load->model('User_model');
	}

	public function index()
	{
		if ($this->session->userdata('logged_in')) {
				$session_data = $this->session->userdata('logged_in');
				$id_login = $session_data['id_login'];
				$username = $session_data['username'];
				$password = $session_data['password'];
				$nama = $session_data['nama'];
				$alamat = $session_data['alamat'];
				$noHp = $session_data['noHp'];
				$level = $session_data['level'];

				$data['level'] = $level;
				$data['user'] = $this->User_model->getUser();

				if ($level == 1) {
					$this->load->view('user/view_user', $data);
				}

		}
		else{
			redirect('login','refresh');
		}
	}

	public function delete($id_login)
	{
		if ($this->session->userdata('logged_in')) {
				$session_data = $this->session->userdata('logged_in');
				$id_login = $session_data['id_login'];
				$username = $session_data['username'];
				$password = $session_data['password'];
				$nama = $session_data['nama'];
				$alamat = $session_data['alamat'];
				$noHp = $session_data['noHp'];
				$level = $session_data['level'];

				$this->User_model->deleteUser($id_login);
				redirect('User','refresh');
		} 
		else {
			redirect('login','refresh');
		}
	}

	public function create()
	{
		if ($this->session->userdata('logged_in')) {
				$session_data = $this->session->userdata('logged_in');
				$id_login = $session_data['id_login'];
				$username = $session_data['username'];
				$password = $session_data['password'];
				$nama = $session_data['nama'];
				$alamat = $session_data['alamat'];
				$noHp = $session_data['noHp'];
				$level = $session_data['level'];

				$this->form_validation->set_rules('username', 'username', 'trim|required');
				$this->form_validation->set_rules('password', 'password', 'trim|required');
				$this->form_validation->set_rules('nama', 'nama' ,'trim|required');
				$this->form_validation->set_rules('alamat', 'Alamat', 'trim|required');
				$this->form_validation->set_rules('noHp', 'Nomor Hp', 'trim|required');

				$data['level'] = $level;

				if ($this->form_validation->run() == FALSE) {
					$this->load->view('user/create', $data);
				} else {
					$this->User_model->createUser();
					redirect('User','refresh');
				}
		} 
		else {
			redirect('login','refresh');
		}
	}
}

/* End of file User.php */
/* Location: ./application/controllers/User.php */ ?>