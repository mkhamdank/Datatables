<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Person extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url','form','file');
		$this->load->library('form_validation');
		$this->load->model('Perusahaan_model');
		$this->load->model('Person_model');
	}

	public function index()
	{
		if ($this->session->userdata('logged_in')) {
				$session_data = $this->session->userdata('logged_in');
				$id_login = $session_data['id_login'];
				$username = $session_data['username'];
				$password = $session_data['password'];
				$nama = $session_data['nama'];
				$seksi = $session_data['seksi'];
				// $noHp = $session_data['noHp'];
				$level = $session_data['level'];

				$data['level'] = $level;
				$data['person'] = $this->Person_model->getPerson();
				$this->load->view('person/view_person',$data);
		}
		else {
			redirect('login','refresh');
		}
	}

	public function update($id_person,$foto_ktp,$foto_diri)
	{
		if ($this->session->userdata('logged_in')) {
				$session_data = $this->session->userdata('logged_in');
				$id_login = $session_data['id_login'];
				$username = $session_data['username'];
				$password = $session_data['password'];
				$nama = $session_data['nama'];
				$seksi = $session_data['seksi'];
				// $noHp = $session_data['noHp'];
				$level = $session_data['level'];

				$this->form_validation->set_rules('nama','nama','trim|required');
				$this->form_validation->set_rules('no_ktp','no_ktp','trim|required');
				$this->form_validation->set_rules('address','addres','trim|required');
				$this->form_validation->set_rules('reg_num','reg_num','trim|required');

				$data['level'] = $level;
				$data['person'] = $this->Person_model->getPersonById($id_person);

				if($this->form_validation->run()==FALSE)
				{
					$this->load->view('person/edit_person_view',$data);
				}
				else
				{
				$config['upload_path'] = './assets/uploads/';
				$config['allowed_types'] = 'jpg|png';
				$config['max_size']  = 10000000;
				$config['max_width']  = 200000;
				$config['max_height']  = 100000;
					
					$this->load->library('upload', $config);
					
					if ( ! $this->upload->do_upload('userfile')){
						$error = array('error' => $this->upload->display_errors());
						$this->load->view('person/edit_person_view', $error);
					}
					else{
						$image_data = $this->upload->data();

						$configer = array (
							'image_library' => 'gd2',
							'source_image' => $image_data['full_path'],
							'maintain_ratio' => TRUE,
							'width' => 500,
							'height' => 768,
							);

						$this->load->library('image_lib', $config);
						$this->image_lib->clear();
						$this->image_lib->initialize($configer);
						$this->image_lib->resize();

						$this->Perusahaan_model->updateById($id_perusahaan);
						redirect('Person','refresh');
					}
				}
		} 
		else {
			redirect('login','refresh');
		}		
	}

	public function delete($id_person,$foto_ktp,$foto_diri)
	{
		if ($this->session->userdata('logged_in')) {
				$session_data = $this->session->userdata('logged_in');
				$id_login = $session_data['id_login'];
				$username = $session_data['username'];
				$password = $session_data['password'];
				$nama = $session_data['nama'];
				$seksi = $session_data['seksi'];
				// $noHp = $session_data['noHp'];
				$level = $session_data['level'];

				unlink("assets/uploads/".$foto_ktp);
				unlink("assets/uploads/".$foto_diri);
				$this->Person_model->delete($id_person);
				redirect('Person','refresh');
		} 
		else {
			redirect('login','refresh');
		}
	}
}

/* End of file Person.php */
/* Location: ./application/controllers/Person.php */