<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url','form','file');
		$this->load->library('form_validation');
		$this->load->model('Perusahaan_model');
		$this->load->model('Person_model');
	}

	public function index()
	{
		$this->load->view('home/perusahaan');
	}

	public function dataPerusahaan(){
    $data['perusahaan'] = $this->Perusahaan_model->getPerusahaan();
    $this->load->view('perusahaan/view_perusahaan',$data);
  	}

	public function daftarPerson()
	{
		$data['person'] = $this->Person_model->getPerson();
		$this->load->view('person/view_person',$data);
	}

	public function create()
	{
		$this->form_validation->set_rules('nama_perusahaan', 'Nama Perusahaan', 'trim|required');
		$this->form_validation->set_rules('alias', 'Alias', 'trim|required');
		$this->form_validation->set_rules('safety_permit_number', 'Safety Permit Number', 'trim|required');
		$this->form_validation->set_rules('mulai_bekerja', 'Mulai Bekerja', 'trim|required');
		$this->form_validation->set_rules('finish_work', 'Terakhir Bekerja', 'trim|required');
		$this->form_validation->set_rules('jumlah_personil', 'Jumlah Personil', 'trim|required');

		if ($this->form_validation->run() == FALSE) {
			$this->load->view('home/create');
		} else {
				$config['upload_path'] = './assets/uploads/';
				$config['allowed_types'] = 'jpg|png';
				$config['max_size']  = 100000;
				$config['max_width']  = 200000;
				$config['max_height']  = 100000;
				
				$this->load->library('upload', $config);
				
				if ( ! $this->upload->do_upload('userfile')){
					$error = array('error' => $this->upload->display_errors());
					$this->load->view('home/create', $error);
				}
				else{
					$image_data = $this->upload->data();

					$configer = array (
						'image_library' => 'gd2',
						'source_image' => $image_data['full_path'],
						'maintain_ratio' => TRUE,
						'width' => 500,
						'height' => 768,
						);

					$this->load->library('image_lib', $config);
					$this->image_lib->clear();
					$this->image_lib->initialize($configer);
					$this->image_lib->resize();

					$this->Perusahaan_model->create();
					$nama_perusahaan = $this->input->post('nama_perusahaan');
					$jumlah_personil = $this->input->post('jumlah_personil');
					$perusahaan = $this->Perusahaan_model->getPerusahaanByNama($nama_perusahaan);
					foreach ($perusahaan as $key) {
						$id_perusahaan = $key->id_perusahaan;
					}
					redirect('Home/create_personil/'.$id_perusahaan.'/'.$jumlah_personil,'refresh');
				}
		}
	}

	public function create_personil($id_perusahaan,$jumlah_personil)
	{
		$this->form_validation->set_rules('hidden', 'Nama Personil', 'trim|required');

		$data['jumlah_personil'] = $jumlah_personil;

		if ($this->form_validation->run() == FALSE) {
			$this->load->view('home/create_personil',$data);
		} else {
				// $config['upload_path'] = './assets/uploads/';
				// $config['allowed_types'] = 'jpg|png';
				// $config['max_size']  = 100000;
				// $config['max_width']  = 200000;
				// $config['max_height']  = 100000;
				
				// $this->load->library('upload', $config);
				
				// if ( ! $this->upload->do_upload('userfile')){
				// 	$data['error'] = $this->upload->display_errors();
				// 	$this->load->view('home/create_personil', $data);
				// }
				// else{
				// 	$image_data = $this->upload->data();

				// 	$configer = array (
				// 		'image_library' => 'gd2',
				// 		'source_image' => $image_data['full_path'],
				// 		'maintain_ratio' => TRUE,
				// 		'width' => 500,
				// 		'height' => 768,
				// 		);

				// 	$this->load->library('image_lib', $config);
				// 	$this->image_lib->clear();
				// 	$this->image_lib->initialize($configer);
				// 	$this->image_lib->resize();

					
					$nama = $this->input->post('nama');
					$no_ktp = $this->input->post('no_ktp');
					$address = $this->input->post('address');
					$person = $this->Person_model->getPerson();
					$perusahaan = $this->Perusahaan_model->getPerusahaanById($id_perusahaan);
					foreach ($perusahaan as $key) {
						$date = $key->reg_date;
						$reg_date = date("Y/m/d", strtotime($date));
					}
					foreach ($person as $val) {
						$reg_num = $val->reg_num;
						$nomor = substr($reg_num, -6);
					}
					for ($i=0; $i < $jumlah_personil; $i++) {
						$nomor = $nomor+1;
						$reg = $reg_date.'.'.$nomor;
						$jmlnomor = strlen($nomor);
						$nomor = str_pad($nomor, 6, '0', STR_PAD_LEFT);
						$reg = $reg_date.'.'.$nomor;
						$this->Person_model->create($nama[$i],$no_ktp[$i],$address[$i],$id_perusahaan,$reg);
					}
					redirect('Home/perusahaan','refresh');
				// }
		}
	}

	public function UpatePerusahaan($id_perusahaan)
	{
		
	}

}

/* End of file Home.php */
/* Location: ./application/controllers/Home.php */