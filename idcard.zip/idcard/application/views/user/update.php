<!DOCTYPE html>
<html lang="">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Data Contractor PT CJI</title>

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="<?php echo base_url('') ?>assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="<?php echo base_url('') ?>assets/datatables.min.css">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
		
	</head>
	<body>
		<div class="container">
			<nav class="navbar navbar-default" role="navigation">
				<div class="container-fluid">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="#">Data Contractor PT CJI</a>
					</div>
			
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse navbar-ex1-collapse">
						<ul class="nav navbar-nav">
							<?php if ($level == 3): ?>
								<li><a class="nav-link" href="<?php echo site_url('Home/create') ?>">Tambah Perusahaan <span class="sr-only">(current)</span></a></li>
								<li class="active"><a class="nav-link" href="<?php echo site_url('Home/report_perusahaan') ?>">Daftar Perusahaan</a></li>
								<li><a class="nav-link" href="<?php echo site_url('Home/report_person') ?>">Daftar Personil</a></li>
							<?php endif ?>
							<?php if ($level == 1): ?>
								<li><a class="nav-link" href="<?php echo site_url('Perusahaan') ?>">Daftar Perusahaan <span class="sr-only">(current)</span></a></li>
								<li><a class="nav-link" href="<?php echo site_url('Person') ?>">Daftar Personil</a></li>
								<li class="nav-item active"><a class="nav-link" href="<?php echo site_url('User') ?>">Daftar User</a></li>
							<?php endif ?>
							<li><a class="nav-link" href="<?php echo site_url('Login/logout') ?>">Logout</a></li>
						</ul>
						
					</div><!-- /.navbar-collapse -->
				</div>
			</nav>
		
								<?php echo form_open_multipart('User/update/'.$this->uri->segment(3)); ?>
								<?php echo validation_errors() ?>
								<legend><center>Update Data User</center></legend>
								<!-- <?php var_dump($peminjam); ?> -->
								<!-- <?php echo validation_errors(); ?> -->
								<div class="form-group" style="color:black;" >

									<?php foreach ($user as $key) { ?>
										<label for="">Username</label>
										<input type="text" class="form-control" name="username" placeholder="Masukkan Username" value="<?php echo $key->username ?>">
										
										<label for="">Password</label>
										<input type="password" class="form-control" name="password" placeholder="Masukkan Password Lagi">
										
										<label for="">Nama</label>
										<input type="text" class= "form-control" name="nama" class="form-control" placeholder="Masukkan Nama" value="<?php echo $key->nama ?>">

										<label for="">Alamat</label>
										<input type="text" class="form-control" name="alamat" placeholder="Masukkan Alamat" value="<?php echo $key->alamat ?>">
										
										<label for="">No Hp</label>
										<input type="text" class="form-control" name="noHp" placeholder="Masukkan Nomor HP" value="<?php echo $key->noHp ?>">

										<label for="">Jabatan</label>
										<select name="level" class="form-control" required="required">
											<option value="<?php echo $key->level ?>"><?php if ($key->level == 1){
												echo "--- Admin ---";
											}
											elseif ($key->level == 2) {
											 	echo "--- PIC ---";
											 }
											 elseif ($key->level == 3) {
											 	echo "--- User ---";
											 } ?></option>
											<option value="1">Admin</option>
											<option value="2">PIC</option>
											<option value="3">User</option>
										</select>
									<?php } ?>
									
								</div>
								<button type="submit" class="btn btn-primary">Submit</button>
					<?php echo form_close(); ?>
					</div>

	<!-- jQuery -->
		<script src="//code.jquery.com/jquery.js"></script>
		<!-- Bootstrap JavaScript -->
		<script src="<?php echo base_url('') ?>assets/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url('') ?>assets/datatables.min.js"></script>
		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
		<script type="text/javascript">
		$(document).ready(function() {
    		$('#example').DataTable();
		} );	
		</script>
	</body>
</html>