<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Person_model extends CI_Model {

	public function getPerson()
	{
		$this->db->join('perusahaan', 'perusahaan.id_perusahaan = person.fk_perusahaan', 'join');
		return $this->db->get('person')->result();
	}

	public function getPersonById($id_person)
	{
		$this->db->where('id_person', $id_person);
		$this->db->join('perusahaan', 'perusahaan.id_perusahaan = person.fk_perusahaan', 'join');
		return $this->db->get('person')->result();
	}

	public function getPersonByPerusahaan($fk_perusahaan)
	{
		$this->db->join('perusahaan', 'perusahaan.id_perusahaan = person.fk_perusahaan', 'join');
		$this->db->where('fk_perusahaan', $fk_perusahaan);
		return $this->db->get('person')->result();
	}

	public function create($nama,$no_ktp,$address,$reg_num,$fk_perusahaan,$foto,$fotoktp)
	{
		$object = array(
		'nama' => $nama,
		'no_ktp' => $no_ktp,
		'address' => $address,
		'fk_perusahaan' => $fk_perusahaan,
		'reg_num' => $reg_num,
		'foto_ktp' => $fotoktp,
		'foto_diri' => $foto);
		$this->db->insert('person', $object);
	}

	public function updateById($id_person)
	{
		$data = array('nama' =>$this->input->post('nama'),
					'no_ktp' =>$this->input->post('no_ktp'),
					'address' =>$this->input->post('address'),
					'reg_num' =>$this->input->post('mulai_bekerja'),
					'foto_diri'=>$this->upload->data('file_name'),
					'foto_ktp'=>$this->upload->data('file_name'),);
		$this->db->where('id_person', $id_person);
		$this->db->update('person', $data);
	}

	public function delete($id_person)
	{
		$this->db->where('id_person', $id_person);
		$this->db->delete('person');
	}
}

/* End of file Pegawai_Model.php */
/* Location: ./application/models/Pegawai_Model.php */
 ?>