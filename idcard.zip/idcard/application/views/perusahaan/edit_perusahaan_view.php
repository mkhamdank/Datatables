<!DOCTYPE html>
<html lang="">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Data Contractor PT CJI</title>

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="<?php echo base_url('') ?>assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="<?php echo base_url('') ?>assets/datatables.min.css">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body>
		<div class="container">
			<nav class="navbar navbar-default" role="navigation">
				<div class="container-fluid">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="#">Data Contractor PT CJI</a>
					</div>
			
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse navbar-ex1-collapse">
						<ul class="nav navbar-nav">
							<?php if ($level == 3): ?>
								<li><a class="nav-link" href="<?php echo site_url('Home/create') ?>">Tambah Perusahaan <span class="sr-only">(current)</span></a></li>
								<li class="active"><a class="nav-link" href="<?php echo site_url('Home/report_perusahaan') ?>">Daftar Perusahaan</a></li>
								<li><a class="nav-link" href="<?php echo site_url('Home/report_person') ?>">Daftar Personil</a></li>
							<?php endif ?>
							<?php if ($level == 1): ?>
								<li class="nav-item active"><a class="nav-link" href="<?php echo site_url('Perusahaan') ?>">Daftar Perusahaan <span class="sr-only">(current)</span></a></li>
								<li><a class="nav-link" href="<?php echo site_url('Person') ?>">Daftar Personil</a></li>
							<?php endif ?>
							<li><a class="nav-link" href="<?php echo site_url('Login/logout') ?>">Logout</a></li>
						</ul>
						
					</div><!-- /.navbar-collapse -->
				</div>
			</nav>
		
								<?php echo form_open_multipart('Perusahaan/update/'.$this->uri->segment(3)); ?>
								<legend style="color:black;">Edit Data Perusahaan</legend>
								<!-- <?php var_dump($peminjam); ?> -->
								<?php echo validation_errors(); ?>
								<div class="form-group" style="color:black;" >

									<label for="">Nama Perusahaan</label>
									<input type="text" class="form-control" id="nama_perusahaan" name="nama_perusahaan" placeholder="Masukkan Nama Perusahaan" value="<?php echo $perusahaan[0]->nama_perusahaan ?>">
									
									<label for="">Alias</label>
									<input type="text" class="form-control" id="alias" name="alias" placeholder="Masukkan Alamat" value="<?php 
									echo $perusahaan[0]->alias ?>">
									
									<label for="">Nomor Safety Permit</label>
									<input type="text" name="safety_permit_number" id="safety_permit_number" class="form-control" value="<?php echo $perusahaan[0]->safety_permit_number ?>" title="">

									<label for="">Mulai Bekerja</label>
									<input type="date" class="form-control" id="mulai_bekerja" name="mulai_bekerja" placeholder="" value="<?php 
									echo $perusahaan[0]->mulai_bekerja ?>">

									<label for="">Selesai Bekerja</label>
									<input type="date" class="form-control" id="finish_work" name="finish_work" placeholder="" value="<?php 
									echo $perusahaan[0]->finish_work ?>">

									<label for="">Tanggal Registrasi</label>
									<input type="date" class="form-control" id="reg_date" name="reg_date" placeholder="" value="<?php 
									echo $perusahaan[0]->reg_date ?>">

									<label for="">Foto Safety Permit Number</label>
									<img width="50" src="<?=base_url("assets/uploads")."/".$perusahaan[0]->foto_safety_permit?>">
									<input type="file" name="userfile" class="form-control">
									
								</div>
								<button type="submit" class="btn btn-primary">Submit</button>
					<?php echo form_close(); ?>
					</div>

	<!-- jQuery -->
		<script src="//code.jquery.com/jquery.js"></script>
		<!-- Bootstrap JavaScript -->
		<script src="<?php echo base_url('') ?>assets/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url('') ?>assets/datatables.min.js"></script>
		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
		<script type="text/javascript">
		$(document).ready(function() {
    		$('#example').DataTable();
		} );	
		</script>
	</body>
</html>