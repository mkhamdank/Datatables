<!DOCTYPE html>
<html lang="">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Data Contractor PT CJI</title>

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="<?php echo base_url('') ?>assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="<?php echo base_url('') ?>assets/datatables.min.css">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body>
		<div class="container">
			<nav class="navbar navbar-default" role="navigation">
				<div class="container-fluid">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="#">Data Contractor PT CJI</a>
					</div>
			
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse navbar-ex1-collapse">
						<ul class="nav navbar-nav">
							<?php if ($level == 3): ?>
								<li><a class="nav-link" href="<?php echo site_url('Home/create') ?>">Tambah Perusahaan <span class="sr-only">(current)</span></a></li>
								<li class="active"><a class="nav-link" href="<?php echo site_url('Home/report_perusahaan') ?>">Daftar Perusahaan</a></li>
								<li><a class="nav-link" href="<?php echo site_url('Home/report_person') ?>">Daftar Personil</a></li>
							<?php endif ?>
							<?php if ($level == 1): ?>
								<li class="nav-item active"><a class="nav-link" href="<?php echo site_url('Perusahaan') ?>">Daftar Perusahaan <span class="sr-only">(current)</span></a></li>
								<li><a class="nav-link" href="<?php echo site_url('Person') ?>">Daftar Personil</a></li>
								<li><a class="nav-link" href="<?php echo site_url('User') ?>">Daftar User</a></li>
							<?php endif ?>
							<?php if ($level == 2): ?>
								<li class="nav-item active"><a class="nav-link" href="<?php echo site_url('Perusahaan') ?>">Daftar Perusahaan <span class="sr-only">(current)</span></a></li>
								<li><a class="nav-link" href="<?php echo site_url('Person') ?>">Daftar Personil</a></li>
							<?php endif ?>
							<li><a class="nav-link" href="<?php echo site_url('Login/logout') ?>">Logout</a></li>
						</ul>
						
					</div><!-- /.navbar-collapse -->
				</div>
			</nav>
						<center><legend>Daftar Perusahaan</legend></center>
						<div class="col-12">
						<div class="table-responsive">
							<table class="table" id="example">
								<thead>
									<tr>
										<th>Nama Perusahaan</th>
										<th>Alias</th>
										<th>Safety Permit Number</th>
										<th>Mulai Bekerja</th>
										<th>Selesai Bekerja</th>
										<th>Tanggal Registrasi</th>
										<th>Foto Safety Permit</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
								<?php foreach($perusahaan as $key){ ?>
									<tr>
										<!-- <td><?php echo $key->id_perusahaan ?></td> -->
										<td><?php echo $key->nama_perusahaan ?></td>
										<td><?php echo $key->alias ?></td>
										<td><?php echo $key->safety_permit_number ?></td>
										<td><?php 
										echo date("d/m/Y", strtotime($key->mulai_bekerja)); ?></td>
										<td><?php echo date("d/m/Y", strtotime($key->finish_work)); ?></td>
										<td><?php echo date("d/m/Y", strtotime($key->reg_date)); ?></td>
										<td><a class="MagicZoom" href="<?=base_url("assets/uploads")."/".$key->foto_safety_permit?>" rel="zoom-id:zoom;opacity-reverse:true;"><img style="width: 100px; height: 50px;" src="<?=base_url("assets/uploads")."/".$key->foto_safety_permit?>" alt="" /> </a></td>
										<td>
										      <a href="<?=site_url()?>/Perusahaan/update/<?php echo $key->id_perusahaan ?>"><button class="btn btn-primary" data-title="Edit" data-toggle="modal" data-target="#edit"><span class="glypchon glypchon-pencil">Edit</span></button></a>
										      <?php if ($level == 1): ?>
										      	<a class="btn btn-danger" href="<?php echo site_url('Perusahaan/delete/'.$key->id_perusahaan) ?>">Delete</a>
										      	<a class="btn btn-success" href="<?php echo site_url('Cetak/filter/'.$key->id_perusahaan) ?>">Print</a>
										      <?php endif ?>
										</td>
									</tr>
								<?php } ?>
								</tbody>
							</table>
						</div>
						</div>
				</div>


		<!-- jQuery -->
		<script src="//code.jquery.com/jquery.js"></script>
		<!-- Bootstrap JavaScript -->
		<script src="<?php echo base_url('') ?>assets/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url('') ?>assets/datatables.min.js"></script>
		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
		<script type="text/javascript">
		$(document).ready(function() {
    		$('#example').DataTable();
		} );	
		</script>
	</body>
</html>