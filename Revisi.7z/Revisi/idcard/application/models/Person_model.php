<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Person_model extends CI_Model {

	public function getPerson()
	{
		$this->db->join('perusahaan', 'perusahaan.id_perusahaan = person.fk_perusahaan', 'join');
		return $this->db->get('person')->result();
	}

	public function getPersonById($id_person)
	{
		$this->db->where('id_person', $id_person);
		$this->db->join('perusahaan', 'perusahaan.id_perusahaan = person.fk_perusahaan', 'join');
		return $this->db->get('person')->result();
	}

	public function create($nama,$no_ktp,$address,$fk_perusahaan,$reg_num)
	{
		$object = array('nama' => $nama,
		'no_ktp' => $no_ktp,
		'address' => $address,
		'fk_perusahaan' => $fk_perusahaan,
		'reg_num' => $reg_num,);
		$this->db->insert('person', $object);
	}

}

/* End of file Person_model.php */
/* Location: ./application/models/Person_model.php */