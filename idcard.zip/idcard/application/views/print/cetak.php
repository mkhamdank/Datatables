<!DOCTYPE html>
<html lang="">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Title Page</title>

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="<?php echo base_url('') ?>assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="<?php echo base_url('') ?>assets/datatables.min.css">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body>
		<!-- <?php var_dump($person) ?> -->
		<table style="text-align: center;">
			<tr>
			<?php for ($i=0;$i<count($person);$i++) { ?>
				<td style="padding-left: 20px"><?php echo $person[$i]->alias ?></td>
			<?php } ?>
			</tr>
			<tr>
			<?php for ($i=0;$i<count($person);$i++) { ?>
				<td style="padding-left: 20px"><?php echo $person[$i]->nama ?></td>
			<?php } ?>
			</tr>
			<tr>
			<?php for ($i=0;$i<count($person);$i++) { ?>
				<td style="padding-left: 20px"><img style="width: 100px;padding-top: 20px" src="<?php echo base_url('assets/uploads/'.$person[$i]->foto_diri) ?>" alt=""></td>
			<?php } ?>
			</tr>
		</table>

		<!-- jQuery -->
		<script src="//code.jquery.com/jquery.js"></script>
		<!-- Bootstrap JavaScript -->
		<script src="<?php echo base_url('') ?>assets/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url('') ?>assets/datatables.min.js"></script>
		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
		<script type="text/javascript">
		$(document).ready(function() {
    		$('#example').DataTable();
		} );	
	</body>
</html>